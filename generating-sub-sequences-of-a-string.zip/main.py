'''
def generate_subsequences(string):
    # Base case: if the string is empty, return a list with an empty string
    if not string:
        return [""]
    
    # Recursive case: get all subsequences of the substring (excluding the first character)
    smaller_subsequences = generate_subsequences(string[1:])
    
    # Create new subsequences by including the first character with each subsequence from the smaller string
    result = smaller_subsequences + [string[0] + subsequence for subsequence in smaller_subsequences]
    
    return result

# Test the function
string = "abcd"
subsequences = generate_subsequences(string)
print(subsequences)
'''


string = "abcd"
subsequences = [""]  # Start with an empty subsequence

# Iteratively generate subsequences by adding each character to existing subsequences
for char in string:
    subsequences += [subseq + char for subseq in subsequences]

print(subsequences)















